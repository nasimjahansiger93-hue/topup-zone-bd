import { json, rowToOrder } from '../_helpers.js';
export async function onRequestGet({params, env}) {
  const row = await env.DB.prepare('SELECT * FROM orders WHERE id = ?').bind(params.id).first();
  if (!row) return json({error:'Order not found'},404);
  // Public tracking response deliberately omits contact, sender number and transaction ID.
  const order = rowToOrder(row);
  delete order.contact; delete order.senderNumber; delete order.transactionId;
  return json(order);
}
