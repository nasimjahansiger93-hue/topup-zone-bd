import { CATALOG, json, isAdmin, rowToOrder, bodyJson } from '../_helpers.js';

export async function onRequestGet({request, env}) {
  if (!isAdmin(request, env)) return json({error:'Admin authentication required'}, 401);
  const url = new URL(request.url);
  const q = (url.searchParams.get('query') || '').trim().slice(0,100);
  let result;
  if (q) {
    const like = `%${q.replace(/[\\%_]/g, '\\$&')}%`;
    result = await env.DB.prepare(`SELECT * FROM orders WHERE id LIKE ? ESCAPE '\\' OR playerId LIKE ? ESCAPE '\\' OR contact LIKE ? ESCAPE '\\' OR game LIKE ? ESCAPE '\\' OR transactionId LIKE ? ESCAPE '\\' ORDER BY createdAt DESC LIMIT 200`).bind(like,like,like,like,like).all();
  } else {
    result = await env.DB.prepare('SELECT * FROM orders ORDER BY createdAt DESC LIMIT 200').all();
  }
  return json({orders:(result.results || []).map(rowToOrder)});
}

export async function onRequestPost({request, env}) {
  const body = await bodyJson(request);
  if (!body) return json({error:'Invalid JSON'},400);
  const game = typeof body.game === 'string' ? body.game.trim() : '';
  const packageName = typeof body.packageName === 'string' ? body.packageName.trim() : '';
  const playerId = typeof body.playerId === 'string' ? body.playerId.trim() : '';
  const contact = typeof body.contact === 'string' ? body.contact.trim() : '';
  const price = CATALOG[game]?.[packageName];
  if (!game || !packageName || !playerId || playerId.length > 100 || contact.length > 40) return json({error:'Valid game, package and player ID are required'},400);
  if (price === undefined) return json({error:'Unknown game/package'},400);
  const id = crypto.randomUUID();
  const createdAt = new Date().toISOString();
  await env.DB.prepare(`INSERT INTO orders (id,game,packageName,playerId,contact,amountTaka,status,paymentStatus,createdAt) VALUES (?,?,?,?,?,?,'PENDING','UNPAID',?)`).bind(id,game,packageName,playerId,contact || null,price,createdAt).run();
  return json({id,game,packageName,playerId,contact:contact || undefined,amountTaka:price,status:'PENDING',paymentStatus:'UNPAID',createdAt},201);
}
