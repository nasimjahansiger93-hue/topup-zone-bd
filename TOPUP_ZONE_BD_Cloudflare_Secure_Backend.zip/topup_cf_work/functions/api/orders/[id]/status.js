import { json, bodyJson, isAdmin, rowToOrder } from '../../_helpers.js';
const STATUSES = ['PENDING','PROCESSING','COMPLETED','CANCELLED'];
const PAYMENT = ['UNPAID','VERIFYING','PAID','REFUNDED'];
export async function onRequestPatch({request, params, env}) {
  if (!isAdmin(request, env)) return json({error:'Admin authentication required'},401);
  const body = await bodyJson(request);
  if (!body || !STATUSES.includes(body.status) || !PAYMENT.includes(body.paymentStatus)) return json({error:'Invalid status values'},400);
  // Completion is forbidden until an admin explicitly marks payment PAID.
  if (body.status === 'COMPLETED' && body.paymentStatus !== 'PAID') return json({error:'Mark payment as PAID before completing an order'},400);
  const result = await env.DB.prepare('UPDATE orders SET status=?, paymentStatus=?, updatedAt=? WHERE id=?').bind(body.status,body.paymentStatus,new Date().toISOString(),params.id).run();
  if (!result.meta?.changes) return json({error:'Order not found'},404);
  const row = await env.DB.prepare('SELECT * FROM orders WHERE id=?').bind(params.id).first();
  return json(rowToOrder(row));
}
