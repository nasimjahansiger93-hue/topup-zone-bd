import { json, bodyJson, rowToOrder } from '../../_helpers.js';
export async function onRequestPost({request, params, env}) {
  const body = await bodyJson(request);
  if (!body) return json({error:'Invalid JSON'},400);
  const transactionId = typeof body.transactionId === 'string' ? body.transactionId.trim().toUpperCase() : '';
  const paymentMethod = typeof body.paymentMethod === 'string' ? body.paymentMethod : '';
  const senderNumber = typeof body.senderNumber === 'string' ? body.senderNumber.trim() : '';
  if (transactionId.length < 5 || transactionId.length > 100) return json({error:'Valid transaction ID required'},400);
  if (!['bKash','Nagad','Rocket'].includes(paymentMethod)) return json({error:'Invalid payment method'},400);
  if (senderNumber.length > 40) return json({error:'Invalid sender number'},400);
  const existing = await env.DB.prepare('SELECT id,status FROM orders WHERE id = ?').bind(params.id).first();
  if (!existing) return json({error:'Order not found'},404);
  if (existing.status === 'CANCELLED') return json({error:'Cancelled orders cannot receive payment'},409);
  const duplicate = await env.DB.prepare('SELECT id FROM orders WHERE transactionId = ? AND id != ?').bind(transactionId,params.id).first();
  if (duplicate) return json({error:'This transaction ID has already been submitted'},409);
  await env.DB.prepare(`UPDATE orders SET paymentMethod=?, transactionId=?, senderNumber=?, paymentStatus='VERIFYING', status=CASE WHEN status='PENDING' THEN 'PROCESSING' ELSE status END, updatedAt=? WHERE id=?`).bind(paymentMethod,transactionId,senderNumber || null,new Date().toISOString(),params.id).run();
  const row = await env.DB.prepare('SELECT * FROM orders WHERE id = ?').bind(params.id).first();
  return json(rowToOrder(row));
}
