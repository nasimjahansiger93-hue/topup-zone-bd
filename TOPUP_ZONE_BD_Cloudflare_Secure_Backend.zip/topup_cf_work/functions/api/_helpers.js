export const CATALOG = {
  'Free Fire': {'100 Diamonds':80,'210 Diamonds':160,'530 Diamonds':390,'1080 Diamonds':780,'Weekly Membership':190,'Monthly Membership':950},
  'PUBG Mobile': {'60 UC':120,'325 UC':590,'660 UC':1150,'1800 UC':2950},
  'Mobile Legends': {'86 Diamonds':140,'172 Diamonds':275,'257 Diamonds':410,'706 Diamonds':1050},
  'FC Mobile': {'Starter Pack':120,'Value Pack':250,'Pro Pack':500,'Mega Pack':950}
};
export function json(data, status=200) {
  return new Response(JSON.stringify(data), {status, headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
}
export function isAdmin(request, env) {
  const expected = env.ADMIN_TOKEN;
  const supplied = request.headers.get('x-admin-token') || '';
  return !!expected && supplied.length === expected.length && supplied === expected;
}
export function rowToOrder(row) {
  if (!row) return null;
  return {id:row.id,game:row.game,packageName:row.packageName,playerId:row.playerId,contact:row.contact || undefined,amountTaka:row.amountTaka,status:row.status,paymentStatus:row.paymentStatus,paymentMethod:row.paymentMethod || undefined,transactionId:row.transactionId || undefined,senderNumber:row.senderNumber || undefined,createdAt:row.createdAt,updatedAt:row.updatedAt || undefined};
}
export async function bodyJson(request) { try { return await request.json(); } catch { return null; } }
