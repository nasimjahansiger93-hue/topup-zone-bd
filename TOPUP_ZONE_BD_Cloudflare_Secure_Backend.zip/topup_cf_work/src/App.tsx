import React, { useState, useEffect, useMemo } from 'react';
import { GAMES_CATALOG } from './data/catalog';
import { GameItem, GamePackage, OrderReceipt } from './types';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { GameList } from './components/GameList';
import { PackageGrid } from './components/PackageGrid';
import { CheckoutColumn } from './components/CheckoutColumn';
import { PaymentModal } from './components/PaymentModal';
import { OrderTrackerModal } from './components/OrderTrackerModal';
import { PaymentGuideModal } from './components/PaymentGuideModal';
import { AdminOrdersModal } from './components/AdminOrdersModal';
import { Footer } from './components/Footer';


export default function App() {
  const games = GAMES_CATALOG;
  const [selectedGameId, setSelectedGameId] = useState<string>(games[0].id);
  const selectedGame = useMemo(
    () => games.find((g) => g.id === selectedGameId) || games[0],
    [games, selectedGameId]
  );

  const [selectedPackageName, setSelectedPackageName] = useState<string>(
    selectedGame.packages[1]?.name || selectedGame.packages[0]?.name || ''
  );

  const selectedPackage = useMemo(
    () => selectedGame.packages.find((p) => p.name === selectedPackageName) || null,
    [selectedGame, selectedPackageName]
  );

  const [activeReceipt, setActiveReceipt] = useState<OrderReceipt | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Orders list state (synced with API & localStorage)
  const [orders, setOrders] = useState<OrderReceipt[]>([]);
  const [adminToken, setAdminToken] = useState<string>(() => sessionStorage.getItem('topupzone_admin_token') || '');

  // Modals state
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentTargetOrder, setPaymentTargetOrder] = useState<OrderReceipt | null>(null);
  const [isTrackerModalOpen, setIsTrackerModalOpen] = useState(false);
  const [trackerInitialId, setTrackerInitialId] = useState('');
  const [isGuideModalOpen, setIsGuideModalOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);

  // Fetch initial orders from backend
  const fetchOrders = async () => {
    try {
      if (!adminToken) return;
      const res = await fetch('/api/orders', { headers: { 'x-admin-token': adminToken } });
      if (res.status === 401) {
        sessionStorage.removeItem('topupzone_admin_token');
        setAdminToken('');
        setOrders([]);
        return;
      }
      if (res.ok) {
        const data = await res.json();
        if (data.orders && Array.isArray(data.orders)) setOrders(data.orders);
      }
    } catch (e) {
      console.warn('Could not fetch backend orders, using local storage cache', e);
    }
  };

  useEffect(() => {
    if (adminToken) fetchOrders();
  }, [adminToken]);

  const handleOpenAdmin = () => {
    const entered = window.prompt('অ্যাডমিন টোকেন দিন (Cloudflare ADMIN_TOKEN):');
    if (!entered) return;
    sessionStorage.setItem('topupzone_admin_token', entered.trim());
    setAdminToken(entered.trim());
    setIsAdminModalOpen(true);
  };

  // When game changes, default to a package
  const handleSelectGame = (game: GameItem) => {
    setSelectedGameId(game.id);
    setSelectedPackageName(game.packages[0]?.name || '');
    setActiveReceipt(null);
  };

  const handleSelectPackage = (pkg: GamePackage) => {
    setSelectedPackageName(pkg.name);
  };

  // Static Cloudflare Pages build: do not create local-only orders.
  // Connect a secure server-side API before accepting real orders.
  const handleSubmitOrder = async (_info: { playerId: string; contact?: string }): Promise<OrderReceipt | null> => {
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          game: selectedGame.name,
          packageName: selectedPackage?.name,
          playerId: _info.playerId,
          contact: _info.contact
        })
      });
      if (!res.ok) return null;
      const createdOrder = await res.json();
      setActiveReceipt(createdOrder);
      setOrders((prev) => [createdOrder, ...prev.filter((o) => o.id !== createdOrder.id)]);
      return createdOrder;
    } catch {
      return null;
    } finally {
      setIsSubmitting(false);
    }
  };

  // Payment submissions must be verified by a server-side API.
  const handleSubmitPayment = async (
    orderId: string,
    data: { paymentMethod: string; transactionId: string; senderNumber?: string }
  ): Promise<boolean> => {
    try {
      const res = await fetch(`/api/orders/${orderId}/pay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!res.ok) return false;
      const updated = await res.json();
      setOrders((prev) => prev.map((ord) => ord.id === orderId ? updated : ord));
      setActiveReceipt((curr) => curr?.id === orderId ? updated : curr);
      return true;
    } catch {
      return false;
    }
  };

  // Status changes are accepted only from the authenticated backend.
  const handleUpdateStatus = async (
    orderId: string,
    status: OrderReceipt['status'],
    paymentStatus: OrderReceipt['paymentStatus']
  ) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-admin-token': adminToken },
        body: JSON.stringify({ status, paymentStatus })
      });
      if (!res.ok) return;
      const updated = await res.json();
      setOrders((prev) => prev.map((ord) => ord.id === orderId ? updated : ord));
      setActiveReceipt((curr) => curr?.id === orderId ? updated : curr);
    } catch (e) {
      console.error('Failed to update status', e);
    }
  };

  const handleOpenPayment = (receipt: OrderReceipt) => {
    setPaymentTargetOrder(receipt);
    setIsPaymentModalOpen(true);
  };

  const handleTrackReceipt = (receipt: OrderReceipt) => {
    setTrackerInitialId(receipt.id);
    setIsTrackerModalOpen(true);
  };

  return (
    <div className="page-grain min-h-[100dvh] flex flex-col justify-between">
      <div>
        <Header
          onOpenTracker={() => {
            setTrackerInitialId('');
            setIsTrackerModalOpen(true);
          }}
          onOpenPaymentGuide={() => setIsGuideModalOpen(true)}
          onOpenAdmin={handleOpenAdmin}
          ordersCount={orders.length}
        />

        <main className="shell main-shell">
          <Hero />

          <section id="games" className="order-layout" aria-label="গেম নির্বাচন ও অর্ডার">
            {/* Catalog Column (Left) */}
            <div className="catalog-column">
              <div className="section-heading">
                <div>
                  <div className="eyebrow">
                    <span className="eyebrow-line"></span> আপনার গেম
                  </div>
                  <h2>কোথায় খেলছেন?</h2>
                </div>
                <span className="section-count font-mono">
                  ০{games.length} / GAMES
                </span>
              </div>

              <GameList
                games={games}
                selectedGameId={selectedGameId}
                onSelectGame={handleSelectGame}
              />

              <PackageGrid
                game={selectedGame}
                selectedPackageName={selectedPackageName}
                onSelectPackage={handleSelectPackage}
              />
            </div>

            {/* Checkout Column (Right) */}
            <CheckoutColumn
              game={selectedGame}
              selectedPackage={selectedPackage}
              onSubmitOrder={handleSubmitOrder}
              isSubmitting={isSubmitting}
              activeReceipt={activeReceipt}
              onDismissReceipt={() => setActiveReceipt(null)}
              onOpenPaymentForReceipt={handleOpenPayment}
              onTrackReceipt={handleTrackReceipt}
            />
          </section>
        </main>
      </div>

      <Footer
        onOpenTracker={() => {
          setTrackerInitialId('');
          setIsTrackerModalOpen(true);
        }}
        onOpenGuide={() => setIsGuideModalOpen(true)}
        onOpenAdmin={handleOpenAdmin}
      />

      {/* Modals */}
      <PaymentModal
        isOpen={isPaymentModalOpen}
        order={paymentTargetOrder}
        onClose={() => setIsPaymentModalOpen(false)}
        onSubmitPayment={handleSubmitPayment}
      />

      <OrderTrackerModal
        isOpen={isTrackerModalOpen}
        initialOrderId={trackerInitialId}
        allOrders={orders}
        onClose={() => setIsTrackerModalOpen(false)}
        onPayForOrder={handleOpenPayment}
      />

      <PaymentGuideModal
        isOpen={isGuideModalOpen}
        onClose={() => setIsGuideModalOpen(false)}
      />

      <AdminOrdersModal
        isOpen={isAdminModalOpen}
        orders={orders}
        onClose={() => setIsAdminModalOpen(false)}
        onUpdateStatus={handleUpdateStatus}
        onRefresh={fetchOrders}
      />
    </div>
  );
}
