CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  game TEXT NOT NULL,
  packageName TEXT NOT NULL,
  playerId TEXT NOT NULL,
  contact TEXT,
  amountTaka INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','PROCESSING','COMPLETED','CANCELLED')),
  paymentStatus TEXT NOT NULL DEFAULT 'UNPAID' CHECK (paymentStatus IN ('UNPAID','VERIFYING','PAID','REFUNDED')),
  paymentMethod TEXT,
  transactionId TEXT,
  senderNumber TEXT,
  createdAt TEXT NOT NULL,
  updatedAt TEXT
);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(createdAt DESC);
CREATE INDEX IF NOT EXISTS idx_orders_trx ON orders(transactionId);
