# TOPUP ZONE BD — Cloudflare Pages + D1 API

এই প্রজেক্টে React/Vite storefront এবং Cloudflare Pages Functions API যুক্ত আছে। অর্ডার Cloudflare D1-এ সংরক্ষিত হবে। কোনো ডেমো অর্ডার seed করা নেই এবং গ্রাহকের দেওয়া TrxID কখনো স্বয়ংক্রিয়ভাবে `PAID` করা হয় না। TrxID জমা হলে সেটি শুধু `VERIFYING` হয়; টাকা সত্যি এসেছে কিনা যাচাই করে অ্যাডমিনকে আলাদাভাবে `PAID` করতে হবে।

## 1. Cloudflare-এ D1 database তৈরি

কম্পিউটারে Node.js 22+ ইনস্টল করে এই ফোল্ডারে Terminal খুলুন:

```bash
npm install
npx wrangler login
npx wrangler d1 create topup-zone-bd-orders
```

Cloudflare যে `database_id` দেবে, সেটি `wrangler.toml`-এ `REPLACE_WITH_YOUR_D1_DATABASE_ID`-এর জায়গায় বসান.

তারপর schema deploy করুন:

```bash
npx wrangler d1 execute topup-zone-bd-orders --remote --file=./schema.sql
```

## 2. Admin token সেট করুন

একটি দীর্ঘ, অনন্য গোপন টোকেন তৈরি করুন (কমপক্ষে 32 random characters) এবং সেটি Pages project-এর secret হিসেবে যোগ করুন:

```bash
npx wrangler pages secret put ADMIN_TOKEN --project-name=topup-zone-bd
```

Prompt এ টোকেনটি paste করুন। টোকেন কখনো frontend code, GitHub repo, বা public message-এ রাখবেন না। অ্যাডমিন ড্যাশবোর্ড খোলার সময় সাইটে এই token চাইবে; এটি ওই browser tab/session-এর `sessionStorage`-এ থাকে। শেয়ার করা কম্পিউটারে ব্যবহার শেষে সাইন আউট/ট্যাব বন্ধ করুন।

## 3. Deploy

প্রজেক্ট GitHub-এ push করে Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git বেছে নিন।

- Framework preset: **Vite**
- Build command: `npm run build:pages`
- Build output directory: `dist`
- Root directory: এই প্রজেক্টের root (যেখানে `package.json` আছে)

Cloudflare Pages project-এ D1 binding যোগ করুন:
- Settings → Functions → D1 database bindings
- Variable name: `DB`
- D1 database: `topup-zone-bd-orders`

`wrangler.toml` ব্যবহার করে Wrangler দিয়ে deploy করলে binding config একই ফাইলে আছে; শুধু database ID অবশ্যই বদলাতে হবে। Pages Dashboard-এ deploy করলে Dashboard-এ binding যোগ করা আবশ্যক। `ADMIN_TOKEN`-ও Production এবং Preview environment-এ প্রয়োজনমতো secret হিসেবে সেট করুন।

## 4. Local preview (ঐচ্ছিক)

```bash
npm install
npm run build:pages
npx wrangler pages dev dist --d1 DB=topup-zone-bd-orders
```

Local D1 setup অনুযায়ী Wrangler-এর local database migration/schema-ও চালাতে হতে পারে। Production schema-এর জন্য উপরের `--remote` command ব্যবহার করুন।

## API safety behavior

- `POST /api/orders`: server-side catalog price যাচাই করে order তৈরি করে। Client থেকে পাঠানো price বিশ্বাস করে না।
- `GET /api/orders/:id`: tracking-এর জন্য সীমিত public fields ফেরত দেয়; contact, sender number, TrxID প্রকাশ করে না।
- `GET /api/orders`: `x-admin-token` ছাড়া অর্ডারের তালিকা দেয় না।
- `POST /api/orders/:id/pay`: TrxID জমা করে `VERIFYING` করে; duplicate TrxID প্রত্যাখ্যান করে; payment confirmation নয়।
- `PATCH /api/orders/:id/status`: admin token আবশ্যক; completed করতে payment status `PAID` হতে হবে।

## Before taking real payments

এটি একটি starter implementation, স্বাধীন security audit বা live payment gateway integration নয়। bKash/Nagad/Rocket payment সত্যতা manual merchant account থেকে যাচাই করুন অথবা official merchant API যুক্ত করুন। Production-এ চালুর আগে Cloudflare Turnstile/rate limiting, monitoring, backup/retention policy, admin login/session management এবং payment workflow পরীক্ষা করুন।
